﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BildelarKT5
{
    public class Dack : Del
    {
        public int Bredd { get; set; }
        public int Höjd { get; set; }
        public int Diameter { get; set; }
        public string Årstid { get; set; }

        public Dack(string delNummer, string produktnamn, double pris, string tillverkare,
             int bredd, int höjd, int diameter, string årsTid)
            : base(delNummer, produktnamn, pris, tillverkare)
        {
            Bredd = bredd;
            Höjd = höjd;
            Diameter = diameter;
            Årstid = årsTid;
        }

        public override string DisplayInfo()
        {
            return base.DisplayInfo() + ", Bredd: " +
                ", Höjd: " + Höjd + ", Diameter: " + Diameter +
                ", Årstid: " + Årstid;
        }

        public override string ShoppingStrategy()
        {
            return "In stores";
        }
    }
}
