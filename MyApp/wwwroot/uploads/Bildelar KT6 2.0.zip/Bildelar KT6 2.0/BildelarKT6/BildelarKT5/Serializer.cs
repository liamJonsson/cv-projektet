﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace BildelarKT5
{
    public class Serializer
    {
        private string fileName;
        public string FileName
        {
            set
            {
                fileName = value;
            }
        }
        public Serializer(string fName)
        {
            FileName = fName;
        }
        public void Serialize (List<Del> delar)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Del>));
            FileStream xmlOut = new FileStream(fileName, FileMode.Create, FileAccess.Write);
            xmlSerializer.Serialize(xmlOut, delar);

            xmlOut.Close();
        }

        public List<Del> Deserialize()
        {
            List<Del> delar;
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Del>));
            FileStream xmlIn = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            delar = (List<Del>)xmlSerializer.Deserialize(xmlIn);
         
            xmlIn.Close();
            return delar;
        }

        public void SerializeMedUsing(List<Del> delar)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Del>));
            using (FileStream xmlOut =
                new FileStream(fileName, FileMode.Create, FileAccess.Write))
            {
                xmlSerializer.Serialize(xmlOut, delar);
            }
        }

        public List<Del> DeserializeMedUsing()
        {
            List<Del> delar;
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Del>));
            using (FileStream xmlIn =
                new FileStream(fileName, FileMode.Open, FileAccess.Read))
            {
                delar = (List<Del>)xmlSerializer.Deserialize(xmlIn);
            }
            return delar;
        }
    }
}
