﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BildelarKT5
{
    public partial class Form1 : Form
    {
        List<Del> Delar;
        Serializer serializer;
        public Form1()
        {
            InitializeComponent();
            Delar = new List<Del>();
            serializer = new Serializer(nameof(Delar)+".xml");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Del delObj = null;

            if (comboBox1.SelectedItem.Equals("MotorOlja"))
            {
                delObj = new MotorOlja(tbDelNummer.Text, tbNamn.Text,
                    Convert.ToDouble(tbPris.Text), tbTillverkare.Text,
                    tbOljaTyp.Text, tbViskositet.Text);
            }

            if (comboBox1.SelectedItem.Equals("Däck"))
            {
                delObj = new Dack(tbDelNummer.Text, tbNamn.Text,
                    Convert.ToDouble(tbPris.Text), tbTillverkare.Text,
                    Convert.ToInt32(tbBredd.Text),
                    Convert.ToInt32(tbHojd.Text),
                    Convert.ToInt32(tbDiameter.Text),
                    tbArsTid.Text);
            }

            Delar.Add(delObj);

            PopulateListBoxMedDelar();
        }

        private void PopulateListBoxMedDelar()
        {
            lbDelar.Items.Clear();
            for (int i = 0; i < Delar.Count; i++)
            {
                Del del = Delar[i];
                lbDelar.Items.Add(del.DelNummer);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.Equals("MotorOlja"))
            {
                panelMotorOlja.Visible = true;
                panelDäck.Visible = false;

                tbDelNummer.Text = "134294";
                tbNamn.Text = "Mobil ESP1 1 Motorolja";
                tbPris.Text = 615.ToString();
                tbTillverkare.Text = "Mobil";

                tbOljaTyp.Text = "Helsyntetisk olja";
                tbViskositet.Text = "5W-30";
            }

            if (comboBox1.SelectedItem.Equals("Däck"))
            {
                panelMotorOlja.Visible = false;
                panelDäck.Visible = true;

                tbDelNummer.Text = "401927";
                tbNamn.Text = "Continental CONTISPORTCONTACT 3";
                tbPris.Text = 2131.ToString();
                tbTillverkare.Text = "Continental";

                tbBredd.Text = 275.ToString();
                tbHojd.Text = 35.ToString();
                tbDiameter.Text = 18.ToString();
                tbArsTid.Text = "Sommar";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panelMotorOlja.Visible = false;
            panelDäck.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FileStream outTextFile =
              new FileStream("SomeTextData.txt", FileMode.Append, FileAccess.Write);
            StreamWriter textOut = new StreamWriter(outTextFile);

            foreach (Del item in Delar)
            {
                textOut.Write(item.DelNummer + ",");
                textOut.Write(item.ProduktNamn + ",");
                textOut.Write(item.Pris + ",");
                textOut.Write(item.Tillverkare + ",");

                if(item is MotorOlja)
                {
                    textOut.Write((item as MotorOlja).OljaTyp + ",");
                    textOut.WriteLine((item as MotorOlja).Viskositetsklass);
                }

                if(item is Dack)
                {
                    textOut.Write((item as Dack).Bredd + ",");
                    textOut.Write((item as Dack).Höjd + ",");
                    textOut.Write((item as Dack).Diameter + ",");
                    textOut.WriteLine((item as Dack).Årstid);
                }
            }

            textOut.Close();
            outTextFile.Close();


        }

        private void button4_Click(object sender, EventArgs e)
        {
            //serializer.Serialize(Delar);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //foreach (var item in serializer.Deserialize())
            //{
            //    listBox1.Items.Add(item.DelNummer);
            //}
        }
    }
}
