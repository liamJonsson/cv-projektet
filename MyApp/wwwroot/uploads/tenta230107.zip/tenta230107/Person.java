
public class Person
{
    //Instance variables
    private String fNamn;
    private String eNamn;
    private double lon;
    
    //Constructor(s)
    public Person(String fNamn, String eNamn, double lon)
    {
        this.fNamn = fNamn;
        this.eNamn = eNamn;
        this.lon = lon;
        
    }

    //UPPGIFT 1
    public boolean loneforhojning(double hojning){
        boolean placeholder = false;
        return placeholder;
    }

}
