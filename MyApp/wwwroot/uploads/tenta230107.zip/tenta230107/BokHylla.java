import java.util.HashMap;

public class BokHylla
{
    //Instance variables
    private HashMap<String,Bok> hyllansBocker;
    
    //Constructor(s)
    public BokHylla()
    {
        hyllansBocker = new HashMap<>();
    }

    //Getters
    public HashMap<String, Bok> getHyllansBocker(){
        return hyllansBocker;
    }
    
    public Bok getEnBok(String sokID){
        return hyllansBocker.get(sokID);
    }
    
    //Setters
    public void registreraBok(String ID, Bok enBok){
        hyllansBocker.put(ID, enBok);
    }

    //Misc

}
