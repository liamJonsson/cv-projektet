
public class Lopare
{
    //Instance variables
    private String namn;
    private int tid; //i sekunder
    
    //Constructor(s)
    public Lopare(String namn, int tid)
    {
        this.namn = namn;
        this.tid = tid;
    }

    //Getters
    public String getNamn(){
        return namn;
    }
    
    public int getTid(){
        return tid;
    }
    
    //Setters


    //Misc

}
