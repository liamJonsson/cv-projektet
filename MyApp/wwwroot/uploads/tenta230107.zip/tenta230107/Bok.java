
public class Bok
{
    //Instance variables
    private String titel;
    private int antalSidor;
    private Forfattare bokensForfattare;
    
    //Constructor(s)
    public Bok(String titel, int antalSidor, Forfattare enForfattare)
    {
        this.titel = titel;
        this.antalSidor = antalSidor;
        bokensForfattare = enForfattare;
    }

    //Getters
    public String getTitel(){
        return titel;
    }
    
    public int getAntalSidor(){
        return antalSidor;
    }
    
    public Forfattare getForfattare(){
        return bokensForfattare;
    }
    
    //Setters
    public void setForfattare(Forfattare enForfattare){
        bokensForfattare = enForfattare;
    }

    //Misc

}
