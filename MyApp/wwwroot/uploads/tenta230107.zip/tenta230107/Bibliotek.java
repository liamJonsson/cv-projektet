import java.util.ArrayList;

public class Bibliotek
{
    //Instance variables
    private ArrayList<BokHylla> allaBokHyllor = new ArrayList<>();
    
    //Constructor(s)
    public Bibliotek()
    {
        allaBokHyllor = new ArrayList<>();
    }

    //Getters

    
    //Setters
    public void registreraBokHylla(BokHylla enBokHylla){
        allaBokHyllor.add(enBokHylla);
    }

    //Misc

}
