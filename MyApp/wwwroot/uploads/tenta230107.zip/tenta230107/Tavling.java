
public class Tavling
{
    //Instance variables
    private Lopare[] lopare;
    
    //Constructor(s)
    public Tavling(int maxAntalLopare)
    {   
        lopare = new Lopare[maxAntalLopare];
    }

    //Getters
    public void laggTillLopare(int index, Lopare nyLopare){
        lopare[index] = nyLopare;
    }
    
    // UPPGIFT 3
    public void skrivUtResultat(){
        
    }    

    //Omvandla sekudner till timmar:minuter:sekunder
    public String omvandlaTid(int tid){
        int timmar = tid / 3600;
        int minuter = (tid % 3600) / 60;
        int sekunder = tid % 60;
        String sMinuter = minuter + "";
        String sSekunder = sekunder + "";
        if(minuter < 10){
            sMinuter = 0 + "" + minuter;
        }
        if(sekunder < 10){
            sSekunder = 0 + "" + sekunder;
        }
        return timmar + ":" + sMinuter + ":" + sSekunder;
    }

}
