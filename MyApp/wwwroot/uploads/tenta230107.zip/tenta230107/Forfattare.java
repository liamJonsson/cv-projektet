public class Forfattare
{
    //Instance variables
    private String namn;
    private int fodelseAr;
    
    //Constructor(s)
    public Forfattare(String namn, int fodelseAr)
    {
        this.namn = namn;
        this.fodelseAr = fodelseAr;
    }

    //Getters
    public String getNamn(){
        return namn;
    }
    
    public int getfodelseAr(){
        return fodelseAr;    
    }
    //Setters


    //Misc

}
