
public class Katt
{
    //Instance variables
    private String namn;
    private String fodelseAr;
    public boolean adopterad;
    private boolean kastrerad;
    private String adopteradAvNamn;
    
    //Constructor(s)
    public Katt(String namn, String fodelseAr)
    {
        this.namn = namn;
        this.fodelseAr= fodelseAr;
        adopterad = false;
    }

    //Getters
    public String getNamn(){
        return namn;
    }
    //Misc
    
    public void andraKattInfo(String namn, String fodelseAr){
        this.namn = namn;
        this.fodelseAr = fodelseAr;
    }

    public void adoptera(String namn){
        adopterad = true;
        adopteradAvNamn = namn;
    }
    
    public void kastrering(String status){
        if(status.equals("kastrera")){
            kastrerad = true;
        }
    }
    
    

}
