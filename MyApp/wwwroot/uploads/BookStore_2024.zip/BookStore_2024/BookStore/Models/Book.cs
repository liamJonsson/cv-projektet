﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BookStore.Models
{
    public class Book
    {
        [Key]
        public string ISBN { get; set; }
        public string Title { get; set; }
        public int PublicationYear { get; set; }
        public string Publisher { get; set; }
        public string City { get; set; }
        public string? AuthorId { get; set; }

        [ForeignKey(nameof(AuthorId))]
        public virtual Author Author { get; set; }
        public virtual ICollection<GenreBooks> GenreBooks { get; set; } = new List<GenreBooks>();
    }
}
