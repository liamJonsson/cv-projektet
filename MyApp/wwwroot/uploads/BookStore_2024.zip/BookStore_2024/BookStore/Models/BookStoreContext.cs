﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace BookStore.Models
{
    public class BookStoreContext : IdentityDbContext<User>
    {
        public BookStoreContext(DbContextOptions<BookStoreContext> options) : base(options) { }

        public DbSet<Book> Books { get; set; } 
        public DbSet<Author> Author { get; set; }
        public DbSet<Genre> Genres { get; set; }
        public DbSet<GenreBooks> GenresBooks { get; set; }
        public DbSet<User> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Author>().HasData(
                new Author
                {
                    AuthorId = "820624-7465",
                    Name = "Jonas Moll"
                },
                new Author
                {
                    AuthorId = "540824-8345",
                    Name = "Jan Guillou"
				},
                new Author 
                { 
                    AuthorId = "350615-6354",
                    Name = "Hans Keilson"
                },
                new Author
                {
                    AuthorId = "071114-0284",
                    Name = "Astrid Lindgren"
                },
                new Author
                {
                    AuthorId = "211224-0482",
                    Name = "Carl Bergstrand"
                },
                new Author
                {
                    AuthorId = "730809-2846",
                    Name = "Katarina Wennstam"
                },
                new Author
                {
                    AuthorId = "640307-2765",
                    Name = "Bret Easton Ellis"
                },
                new Author
                {
                    AuthorId = "630603-9573",
                    Name = "Jan Gradvall"
                },
                new Author
                {
                    AuthorId = "811202-8364",
                    Name = "Britney Spears"
                }
            );
            modelBuilder.Entity<Book>().HasData(
                new Book
                {
                    ISBN = "734564",
                    Title = "The role of modality combinations",
                    PublicationYear = 2014,
                    Publisher = "KTH",
                    City = "Stockholm",
                    AuthorId = "820624-7465"
                },
                new Book
                {
                    ISBN = "9789188155443",
                    Title = "Komedi i moll",
                    PublicationYear = 2018,
                    Publisher = "Nilsson Förlag",
                    City = "Höllviken",
                    AuthorId = "350615-6354"
                },
                new Book
                {
                    ISBN = "9789113129419",
                    Title = "Min barndoms jul",
                    PublicationYear = 2023,
                    Publisher = "Norstedts",
                    City = "Stockholm",
                    AuthorId = "071114-0284"
                },
                new Book
                {
                    ISBN = "9789129743111",
                    Title = "Pippi räddar julen",
                    PublicationYear = 2023,
                    Publisher = "Rabén & Sjögren",
                    City = "Stockholm",
                    AuthorId = "071114-0284"
                },
                new Book
                {
                    ISBN = "9789171266095",
                    Title = "Norrsken : den heltäckande handboken",
                    PublicationYear = 2021,
                    Publisher = "Max Ström",
                    City = "Sandhamn",
                    AuthorId = "211224-0482"
                },
                new Book
                {
                    ISBN = "9789189750081",
                    Title = "Döda kvinnor förlåter inte",
                    PublicationYear = 2023,
                    Publisher = "Bookmark förlag",
                    City = "Stockholm",
                    AuthorId = "730809-2846"
                },
                new Book
                {
                    ISBN = "9789178093168",
                    Title = "Skärvorna",
                    PublicationYear = 2023,
                    Publisher = "Blombergs",
                    City = "Stockholm",
                    AuthorId = "640307-2765"
                },
                new Book
                {
                    ISBN = "9789100196912",
                    Title = "Vemod undercover : boken om ABBA",
                    PublicationYear = 2023,
                    Publisher = "Albert Bonniers förlag",
                    City = "Stockholm",
                    AuthorId = "630603-9573"
                },
                new Book
                {
                    ISBN = "9789146240716",
                    Title = "Ristmärken",
                    PublicationYear = 1973,
                    Publisher = "Wahlström & Widstrand",
                    City = "Stockholm",
                    AuthorId = "730809-2846"
                },
                new Book
                {
                    ISBN = "9789137506173",
                    Title = "The woman in me",
                    PublicationYear = 1981,
                    Publisher = "Bokförlaget Forum",
                    City = "Stockholm",
                    AuthorId = "811202-8364"
                }
            );

            modelBuilder.Entity<Genre>().HasData(
                new Genre
                {
                    Id = 1,
                    Name = "Poesi"
                },
                new Genre
                {
                    Id = 2,
                    Name = "Science fiction"
                },
                new Genre
                {
                    Id = 3, 
                    Name = "Komedi"
                },
                new Genre
                {
                    Id = 4, 
                    Name = "Mat"
                },
                new Genre
                {
                    Id = 5,
                    Name = "Barnböcker"
                },
                new Genre
                {
                    Id = 6,
                    Name = "Fakta"
                },
                new Genre
                {
                    Id = 7,
                    Name = "Deckare"
                }
            );

            modelBuilder.Entity<GenreBooks>().HasKey(km => new { km.BookId, km.GenreId });

            modelBuilder.Entity<GenreBooks>().HasData(
                new GenreBooks
                {
                    BookId = "734564",
                    GenreId = 1
                },
                new GenreBooks
                {
                    BookId = "734564",
                    GenreId = 2
                },
                new GenreBooks
                {
                    BookId = "9789188155443",
                    GenreId = 3
                },
                new GenreBooks
                {
                    BookId = "9789113129419",
                    GenreId = 4
                },
                new GenreBooks
                {
                    BookId = "9789129743111",
                    GenreId = 2
                },
                new GenreBooks
                {
                    BookId = "9789129743111",
                    GenreId = 5
                },
                new GenreBooks
                {
                    BookId = "9789171266095",
                    GenreId = 6
                },
                new GenreBooks
                {
                    BookId = "9789189750081",
                    GenreId = 2
                },
                new GenreBooks
                {
                    BookId = "9789189750081",
                    GenreId = 7
                },
                new GenreBooks
                {
                    BookId = "9789178093168",
                    GenreId = 2
                },
                new GenreBooks
                {
                    BookId = "9789178093168",
                    GenreId = 7
                },
                new GenreBooks
                {
                    BookId = "9789100196912",
                    GenreId = 6
                },
                new GenreBooks
                {
                    BookId = "9789146240716",
                    GenreId = 7
                },
                new GenreBooks
                {
                    BookId = "9789137506173",
                    GenreId = 1
                },
                new GenreBooks
                {
                    BookId = "9789137506173",
                    GenreId = 6
                }
            );

            modelBuilder.Entity<Book>().HasOne(p => p.Author).WithMany(a => a.Books).OnDelete(DeleteBehavior.SetNull);
            modelBuilder.Entity<Author>().HasMany(b => b.Books).WithOne(a => a.Author).OnDelete(DeleteBehavior.SetNull);
            modelBuilder.Entity<GenreBooks>().HasOne(p => p.Book).WithMany(a => a.GenreBooks).OnDelete(DeleteBehavior.Restrict);
        }
    }
}
