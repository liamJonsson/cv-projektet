﻿using System.ComponentModel.DataAnnotations.Schema;

namespace BookStore.Models
{
    public class GenreBooks
    {
        public string BookId { get; set; }
        public int GenreId { get; set; }

        [ForeignKey(nameof(BookId))]
        public virtual Book Book { get; set; }
        [ForeignKey(nameof(GenreId))]
        public virtual Genre Genre { get; set;}
    }
}
