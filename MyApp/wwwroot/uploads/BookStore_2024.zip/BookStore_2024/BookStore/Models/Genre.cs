﻿using System.ComponentModel.DataAnnotations.Schema;

namespace BookStore.Models
{
    public class Genre
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string Name { get; set; }

        public virtual ICollection<GenreBooks> GenreBooks { get; set; } = new List<GenreBooks>();
    }
}
