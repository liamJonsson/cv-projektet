using BookStore.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Diagnostics;

namespace BookStore.Controllers
{
    public class HomeController : Controller
    {
        private BookStoreContext context;

        public HomeController(BookStoreContext _context)
        {
            context = _context;
        }

        public IActionResult Index(string? author, string? genre)
        {
            List<SelectListItem> authorList = new List<SelectListItem>();
            authorList.Add(new SelectListItem { Text = "Alla f�rfattare", Value = "" });
            authorList.AddRange(context.Author.Select(x => new SelectListItem { Text = x.Name, Value = x.AuthorId }).ToList());
            foreach(SelectListItem item in authorList)
            {
                if(item.Value == author)
                {
                    item.Selected = true;
                    break;
                }
            }
            ViewBag.authors = authorList;

            List<SelectListItem> genreList = new List<SelectListItem>();
            genreList.Add(new SelectListItem { Text = "Alla genres", Value = "" });
            genreList.AddRange(context.Genres.Select(x => new SelectListItem { Text = x.Name, Value = x.Id.ToString() }).ToList());
			foreach (SelectListItem item in genreList)
			{
				if (item.Value == genre)
				{
					item.Selected = true;
					break;
				}
			}
            ViewBag.genres = genreList;

			IEnumerable<Book> books = context.Books.ToList();

            if (!string.IsNullOrEmpty(author))
            {
                books = books.Where(b => b.AuthorId == author).ToList();
            }
            if(!string.IsNullOrEmpty(genre))
            {
                var bookIds = from book in context.GenresBooks where book.GenreId.ToString().Equals(genre) select book.BookId;
                bookIds = bookIds.Distinct();

                books = books.Where(book => bookIds.Contains(book.ISBN)).ToList();
            }
            return View(books);
        }

    }
}
