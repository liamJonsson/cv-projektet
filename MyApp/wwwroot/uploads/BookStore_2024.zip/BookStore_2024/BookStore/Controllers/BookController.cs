﻿using BookStore.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace BookStore.Controllers
{
    public class BookController : Controller
    {
        private BookStoreContext context;

        public BookController(BookStoreContext _context) {
            context = _context;
        }

        [HttpGet]
        public IActionResult Add() {
            List<SelectListItem> authors = context.Author.Select(x => new SelectListItem{Text=x.Name, Value=x.AuthorId}).ToList();
            ViewBag.options = authors;

            Book book = new Book();
            return View(book);
        }

        [HttpPost]
        public IActionResult Add(Book book) { 
            context.Books.Add(book);
            context.SaveChanges();
            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public IActionResult Remove(string id)
        {
            Book book = context.Books.Find(id);
            return View(book);
        }

        [HttpPost]
        public IActionResult Removing(string id) { 
            Book book = context.Books.Find(id);
            context.Remove(book);
            context.SaveChanges();
            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public IActionResult Edit(string id)
        {
            List<SelectListItem> authors = context.Author.Select(x => new SelectListItem { Text = x.Name, Value = x.AuthorId }).ToList();
            authors.Add(new SelectListItem { Text = "Okänd författare", Value = null });
            ViewBag.options = authors;

            Book book = context.Books.Find(id);
            return View(book);
        }

        [HttpPost]
        public IActionResult Edit(Book book)
        {
            context.Books.Update(book);
            context.SaveChanges();
            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public IActionResult Details(string id) 
        {
            Book book = context.Books.Find(id);
            return View(book);
        }
    }
}
