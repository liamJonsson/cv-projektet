﻿using BookStore.Models;
using Microsoft.AspNetCore.Mvc;

namespace BookStore.Controllers
{
    public class AuthorController : Controller
    {
        private BookStoreContext context;

        public AuthorController(BookStoreContext _context) 
        { 
            context = _context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            IEnumerable<Author> authorList = context.Author.ToList();
            return View(authorList);
        }

        [HttpGet]
        public IActionResult Add()
        {
            Author author = new Author();
            return View(author);
        }

        [HttpPost]
        public IActionResult Add(Author author) 
        { 
            context.Add(author);
            context.SaveChanges();
            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public IActionResult Remove(string id) 
        {
            Author author = context.Author.Find(id);
            return View(author);
        }

        [HttpPost]
        public IActionResult RemoveConfirmed(string id)
        {
            Author author = context.Author.Find(id);
            context.Remove(author);
            context.SaveChanges();
            return RedirectToAction("Index", "Home");
        }
    }
}
