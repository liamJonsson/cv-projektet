﻿using Models;
using System.ServiceModel.Syndication;
using System.Xml;

namespace DAL
{
    public class RssNyhetsKlient
    {
        private HttpClient enHttpKlient;


        public RssNyhetsKlient(HttpClient enHttpKlient)
        {
            this.enHttpKlient = enHttpKlient;
        }

        public async Task<List<Nyhet>> HämtaNyheter(string rssLank)
        {
            Stream dataStrom = await this.enHttpKlient.GetStreamAsync(rssLank);
            XmlReader minXMLlasare = XmlReader.Create(dataStrom);
            SyndicationFeed dataFlode = SyndicationFeed.Load(minXMLlasare);

            minXMLlasare.Dispose();     //ett ännu bättre sätt än .Dispose() är att sätta using 
            dataStrom.Dispose();        //framför Stream dataStrom = await ... och XmlReader minXMLlasare... 
                                        //då slipper man tänka på att stänga/göra dispose. Jag gör det dock
                                        //manuellt här för att uppmärksamma att det xml-läsaren och strömmen
                                        //måste stängas

            List<Nyhet> nyhetslista = new List<Nyhet>();

            foreach (SyndicationItem item in dataFlode.Items)
            {
                Nyhet enNyhet = new Nyhet(); //här skapas alltså nyhetsobjekten
                enNyhet.Id = item.Id.ToString(); //hämtar det id RSS-flödet givit nyheten
                enNyhet.Rubrik = item.Title.Text;
                enNyhet.Publiceringsdatum = item.PublishDate;
                enNyhet.Länk = item.Links.First().Uri.ToString();  //förutsätter att det alltid finns minst en länk
                
                nyhetslista.Add(enNyhet);
            }

            return nyhetslista;
        }


    }
}
