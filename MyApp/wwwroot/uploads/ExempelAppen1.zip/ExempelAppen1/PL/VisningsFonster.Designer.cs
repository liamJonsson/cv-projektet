﻿namespace PL
{
    partial class VisningsFonster
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabHämtaKälla = new TabPage();
            rtbVisaNyhet = new RichTextBox();
            tbUrl = new TextBox();
            lblAngeKälla = new Label();
            btnHämtaKälla = new Button();
            lbRubriker = new ListBox();
            tabCGemensam = new TabControl();
            tabHämtaKälla.SuspendLayout();
            tabCGemensam.SuspendLayout();
            SuspendLayout();
            // 
            // tabHämtaKälla
            // 
            tabHämtaKälla.Controls.Add(rtbVisaNyhet);
            tabHämtaKälla.Controls.Add(tbUrl);
            tabHämtaKälla.Controls.Add(lblAngeKälla);
            tabHämtaKälla.Controls.Add(btnHämtaKälla);
            tabHämtaKälla.Controls.Add(lbRubriker);
            tabHämtaKälla.Location = new Point(4, 29);
            tabHämtaKälla.Name = "tabHämtaKälla";
            tabHämtaKälla.Padding = new Padding(3);
            tabHämtaKälla.Size = new Size(676, 464);
            tabHämtaKälla.TabIndex = 0;
            tabHämtaKälla.Text = "Hämta källa";
            tabHämtaKälla.UseVisualStyleBackColor = true;
            // 
            // rtbVisaNyhet
            // 
            rtbVisaNyhet.Location = new Point(355, 136);
            rtbVisaNyhet.Name = "rtbVisaNyhet";
            rtbVisaNyhet.Size = new Size(273, 224);
            rtbVisaNyhet.TabIndex = 4;
            rtbVisaNyhet.Text = "";
            // 
            // tbUrl
            // 
            tbUrl.Location = new Point(40, 41);
            tbUrl.Name = "tbUrl";
            tbUrl.Size = new Size(309, 27);
            tbUrl.TabIndex = 2;
            // 
            // lblAngeKälla
            // 
            lblAngeKälla.AutoSize = true;
            lblAngeKälla.Location = new Point(40, 18);
            lblAngeKälla.Name = "lblAngeKälla";
            lblAngeKälla.Size = new Size(204, 20);
            lblAngeKälla.TabIndex = 1;
            lblAngeKälla.Text = "Ange källans url (RSS-adress):";
            // 
            // btnHämtaKälla
            // 
            btnHämtaKälla.Location = new Point(40, 80);
            btnHämtaKälla.Name = "btnHämtaKälla";
            btnHämtaKälla.Size = new Size(224, 29);
            btnHämtaKälla.TabIndex = 0;
            btnHämtaKälla.Text = "Hämta och visa nyhetskälla";
            btnHämtaKälla.UseVisualStyleBackColor = true;
            btnHämtaKälla.Click += btnHämtaKälla_Click;
            // 
            // lbRubriker
            // 
            lbRubriker.FormattingEnabled = true;
            lbRubriker.Location = new Point(40, 136);
            lbRubriker.Name = "lbRubriker";
            lbRubriker.Size = new Size(276, 224);
            lbRubriker.TabIndex = 3;
            lbRubriker.SelectedIndexChanged += lbRubriker_SelectedIndexChanged;
            // 
            // tabCGemensam
            // 
            tabCGemensam.Controls.Add(tabHämtaKälla);
            tabCGemensam.Dock = DockStyle.Fill;
            tabCGemensam.Location = new Point(0, 0);
            tabCGemensam.Name = "tabCGemensam";
            tabCGemensam.SelectedIndex = 0;
            tabCGemensam.Size = new Size(684, 497);
            tabCGemensam.TabIndex = 5;
            // 
            // VisningsFonster
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(684, 497);
            Controls.Add(tabCGemensam);
            Name = "VisningsFonster";
            Text = "VisningsFonster";
            //Load += VisningsFonster_Load;
            tabHämtaKälla.ResumeLayout(false);
            tabHämtaKälla.PerformLayout();
            tabCGemensam.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TabPage tabHämtaKälla;
        private RichTextBox rtbVisaNyhet;
        private TextBox tbUrl;
        private Label lblAngeKälla;
        private Button btnHämtaKälla;
        private ListBox lbRubriker;
        private TabControl tabCGemensam;
    }
}
