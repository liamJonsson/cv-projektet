using BL;
using Models;

namespace PL
{
    public partial class VisningsFonster : Form
    {
        private NyhetsAppService enNyhetsService;
        private List<Nyhet> allaNyheter;

        public VisningsFonster(NyhetsAppService enNyhetsService)
        {
            this.enNyhetsService = enNyhetsService;
            InitializeComponent();
        }

        private async void btnH�mtaK�lla_Click(object sender, EventArgs e)
        {
            try
            {
                // 1. Skapa en NyhetsK�lla utifr�n formul�ret
                var k�lla = new NyhetsK�lla();
                k�lla.Id = Guid.NewGuid().ToString(); //fixar auto-id
                k�lla.Url = tbUrl.Text; 

                // 2. H�mta och koppla nyheter till k�llan via BL
                allaNyheter = await enNyhetsService.L�sInAllaNyheter(k�lla);

                // 3. Populera listan
                lbRubriker.Items.Clear();
                rtbVisaNyhet.Clear();

                foreach (Nyhet enNyhet in allaNyheter)
                {
                    lbRubriker.Items.Add(enNyhet);
                }

                lbRubriker.DisplayMember = "Rubrik";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Kunde inte h�mta nyheter: " + ex.Message);
            }
        }

        private void lbRubriker_SelectedIndexChanged(object sender, EventArgs e)
        {
            Nyhet valdNyhet = (Nyhet)lbRubriker.SelectedItem;

            rtbVisaNyhet.Text =
                $"{valdNyhet.Publiceringsdatum} \n {valdNyhet.L�nk}";
        }

    }
}            

