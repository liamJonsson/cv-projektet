
using BL;
using DAL;

namespace PL
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            HttpClient http = new HttpClient();
            var klient = new RssNyhetsKlient(http);
            
            var service = new NyhetsAppService(klient);

            ApplicationConfiguration.Initialize();
            Application.Run(new VisningsFonster(service));
        }        

    }
}