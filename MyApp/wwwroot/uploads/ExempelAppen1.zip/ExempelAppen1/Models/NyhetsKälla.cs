﻿namespace Models
{    
    public class NyhetsKälla
    {
        public string Id { get; set; }
        public string Namn { get; set; }
        public string Url { get; set; }
        public string Kategori { get; set; }

        public NyhetsKälla() 
        {

        }
 
    }
}
