﻿namespace Models
{
    public class Nyhet
    {
        public string Id { get; set; } 
        public string Rubrik { get; set; }
        public DateTimeOffset Publiceringsdatum { get; set; }        
        public string Länk { get; set; }
        
        //KällaReferens är id från nyheten källa. Sätts först senare
        public string? KällaReferens { get; set; } 


        public Nyhet()
        {

        }

    }
}
