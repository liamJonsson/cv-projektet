﻿
using DAL;
using Models;

namespace BL
{
    public class NyhetsAppService
    {
        private RssNyhetsKlient nyhetsKlient;

        public NyhetsAppService(RssNyhetsKlient klient)
        {
            this.nyhetsKlient = klient;
        }

        public async Task<List<Nyhet>> LäsInAllaNyheter(NyhetsKälla källa)
        {
            // Hämta nyheter från RSS utifrån källans URL
            var nyheter = await nyhetsKlient.HämtaNyheter(källa.Url);

            // Koppla varje nyhet till källan och skapa komposit-Id
            foreach (var nyhet in nyheter)
            {
                nyhet.KällaReferens = källa.Id;
                nyhet.Id = källa.Id + "-->" + nyhet.Id; //ändrar så id blir unikt
            }    

            return nyheter;
        }
    

     
    }
}
