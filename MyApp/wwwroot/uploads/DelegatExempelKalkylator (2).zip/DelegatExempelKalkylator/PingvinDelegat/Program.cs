﻿using System;

namespace PingvinDelegat
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Pingvin pingvin1 = new Pingvin("Pingu", 12.5, 7.4);

            pingvin1.SkrivUtInfo();

            AktivitetsDelegat aktiviteter = new AktivitetsDelegat(pingvin1.AtaFrukost);
            aktiviteter += pingvin1.PutsaFjadrarna;
            aktiviteter += pingvin1.Simma;            
            aktiviteter += pingvin1.Sova;

            
            aktiviteter?.Invoke();

            Console.WriteLine();
            pingvin1.SkrivUtInfo();


        }
    }
}
