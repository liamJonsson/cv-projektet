﻿namespace PingvinDelegat
{
    public delegate void AktivitetsDelegat();
}