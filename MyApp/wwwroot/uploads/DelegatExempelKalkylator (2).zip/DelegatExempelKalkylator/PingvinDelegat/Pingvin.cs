﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PingvinDelegat
{
    public class Pingvin
    {
        private double energiNiva;
        public string Namn { get; set; }
        public double Vikt { get; set; }
        public double VingBredd { get; set; }

        public Pingvin(string namn, double vikt, double vingBredd)
        {
            Namn = namn;
            Vikt = vikt;
            VingBredd = vingBredd;
            energiNiva = 0;
        }

        public void AtaFrukost()
        {
            Console.WriteLine($"{Namn} äter frukost!");
            energiNiva = energiNiva + 3;
            Vikt = Vikt + 0.5;
        }

        public void PutsaFjadrarna()
        {
            Console.WriteLine($"{Namn} putsar sina fjädrar.");
            energiNiva = energiNiva - 0.3;
            Vikt = Vikt - 0.2;
        }

        public void Simma()
        {
            Console.WriteLine($"{Namn} simmar glatt!");
            energiNiva = energiNiva - 0.5;
            Vikt = Vikt + 0.1;

        }

        public void Sova()
        {
            Console.WriteLine($"{Namn} sover sött.");
            energiNiva = energiNiva + 1;
        }

        public void SkrivUtInfo()
        {
            Console.WriteLine($"Namn: {Namn}");
            Console.WriteLine($"Vikt: {Vikt} kg");
            Console.WriteLine($"VingBredd: {VingBredd} cm");
            Console.WriteLine($"EnergiNiva: {energiNiva}");
            Console.WriteLine();
        }
    }
}
