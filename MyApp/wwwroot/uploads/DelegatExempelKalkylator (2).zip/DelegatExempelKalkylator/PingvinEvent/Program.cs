﻿using System;

namespace PingvinEvent
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Pingvin pingvin1 = new Pingvin("Pingu", 12.5, 7.4);
            PingvinSkotare skötare = new PingvinSkotare();

            // Prenumerera på eventet
            pingvin1.EnergiForLag += skötare.OnEnergiForLag;
            

            pingvin1.AtaFrukost();

            pingvin1.SkrivUtInfo();

            pingvin1.Simma();
            //pingvin1.Simma();
            //pingvin1.Simma();

        }
    }
}
