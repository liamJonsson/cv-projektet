﻿namespace PingvinEvent
{
    // Definierar delegat för eventet
    public delegate void EnergiForLagEventHandler(object source, EventArgs args);
}