﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PingvinEvent
{
    public class PingvinSkotare
    {
        public string Namn { get; set; }

        public void OnEnergiForLag(object source, EventArgs args)
        {
            Console.WriteLine("PingvinSkötaren säger: Pingvinen behöver vila!");
        }
    }
}
