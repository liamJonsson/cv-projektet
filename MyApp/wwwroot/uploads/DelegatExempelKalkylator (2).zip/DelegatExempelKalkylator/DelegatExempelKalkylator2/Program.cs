﻿//using DelegatExempel;

namespace DelegatExempelKalkylator
{
    public class Program
    {
        public static void Main()
        {
            Kalkylator kalkylator = new Kalkylator();
            UtrakningsDelegat summering = new UtrakningsDelegat(kalkylator.BeraknaSumma);
            UtrakningsDelegat subtrahering = new UtrakningsDelegat(kalkylator.BeraknaDifferensen);
            UtrakningsDelegat division = new UtrakningsDelegat(kalkylator.BeraknaKvoten);

            List<UtrakningsDelegat> utrakningsLista = new List<UtrakningsDelegat>();
            utrakningsLista.Add(kalkylator.BeraknaSumma);
            utrakningsLista.Add(kalkylator.BeraknaDifferensen);
            utrakningsLista.Add(kalkylator.BeraknaKvoten);

            // Exempeldata för beräkningarna
            int tal1 = 10, tal2 = 5;

            // Itererar över varje delegat i listan och anropar den metod den "pekar" på
            foreach (UtrakningsDelegat utrakning in utrakningsLista)
            {
                double resultat = utrakning(tal1, tal2);
                Console.WriteLine("Resultat: "+ resultat);
            }

        }
            
    }
}