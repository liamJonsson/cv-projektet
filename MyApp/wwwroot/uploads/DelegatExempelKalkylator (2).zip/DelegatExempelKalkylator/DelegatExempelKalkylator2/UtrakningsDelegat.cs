﻿namespace DelegatExempelKalkylator
{
    // Delegattypen är definierad i sin egen fil, vilket gör den lättare att hitta och återanvända.
    public delegate double UtrakningsDelegat(int tal1, int tal2);
}