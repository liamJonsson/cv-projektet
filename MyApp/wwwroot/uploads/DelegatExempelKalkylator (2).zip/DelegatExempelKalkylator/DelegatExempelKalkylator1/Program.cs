﻿//using DelegatExempel;

namespace DelegatExempelKalkylator
{
    public class Program
    {
        public static void Main()
        {
            Kalkylator kalkylator = new Kalkylator();
            UtrakningsDelegat utrakning = new UtrakningsDelegat(kalkylator.BeraknaSumma);

            double resultat = utrakning(5, 6);
            Console.WriteLine(resultat);
        }
            
    }
}