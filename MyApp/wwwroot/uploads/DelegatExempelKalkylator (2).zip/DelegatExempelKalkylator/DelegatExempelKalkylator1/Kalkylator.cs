﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatExempelKalkylator
{    

    public class Kalkylator
    {
        // Metod som beräknar summan av två tal
        public double BeraknaSumma(int tal1, int tal2)
        {
            return tal1 + tal2;
        }

        // Metod som beräknar differensen mellan två tal
        public double BeraknaDifferensen(int tal1, int tal2)
        {
            return tal1 - tal2;
        }

        // Metod som beräknar kvoten av två tal
        public double BeraknaKvoten(int tal1, int tal2)
        {
            return tal1 / tal2;
        }
    }
}
