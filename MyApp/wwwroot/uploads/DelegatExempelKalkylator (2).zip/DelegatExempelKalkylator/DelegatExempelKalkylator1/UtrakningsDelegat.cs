﻿namespace DelegatExempelKalkylator
{
    // Delegattypen är definierad i sin egen fil, vilket gör den lättare att hitta och återanvända.
    // Det är inte heller ovanligt att man placerar sådan här definitioner direkt efter namespace-måsvingen
    // i samma fil som den klass som anvöner delegattypen mest. Det här känns dock med logiskt enligt mig

    public delegate double UtrakningsDelegat(int tal1, int tal2);
}