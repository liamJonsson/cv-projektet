﻿using System;
namespace Bildelar
{
    public class Dack : Del
    {
        public int Bredd { get; set; }
        public int Hojd { get; set; }
        public int Diameter { get; set; }
        public string Arstid { get; set; }

        public Dack(string delNummer, double pris, string tillverkare,
            string beskrivning, int bredd, int höjd, int diameter, string årsTid)
            : base(delNummer, pris, tillverkare, beskrivning)
        {
            Bredd = bredd;
            Hojd = höjd;
            Diameter = diameter;
            Arstid = årsTid;
        }

        public override string DisplayInfo()
        {
            return base.DisplayInfo() + ", Bredd: " +
                ", Höjd: " + Hojd + ", Diameter: " + Diameter +
                ", Årstid: " + Arstid;
        }
    }

}

