﻿using System;
namespace Bildelar
{
    public class Del
    {
        public string DelNummer { get; set; }
        public double Pris { get; set; }
        public string Tillverkare { get; set; }
        public string Beskrivning { get; set; }

        public Del(string delNummer, double pris, string tillverkare,
            string beskrivning)
        {
            DelNummer = delNummer;
            Pris = pris;
            Tillverkare = tillverkare;
            Beskrivning = beskrivning;
        }

        public virtual string DisplayInfo()
        {
            return "Del nummer: " +DelNummer  + ", Pris: " + Pris +
                ", Tillverkare: " + Tillverkare + ", Beskrivning: " +Beskrivning;
        }
    }

}
