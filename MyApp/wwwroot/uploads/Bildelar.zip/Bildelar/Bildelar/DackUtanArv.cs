﻿using System;
namespace Bildelar
{
    public class DackUtanArv
    {
        public string DelNummer { get; set; }
        public double Pris { get; set; }
        public string Tillverkare { get; set; }
        public string Beskrivning { get; set; }
        public int Bredd { get; set; }
        public int Hojd { get; set; }
        public int Diameter { get; set; }
        public string Årstid { get; set; }

        public DackUtanArv(string delNummer, double pris, string tillverkare,
            string beskrivning, int bredd, int höjd,
            int diameter, string årsTid)
        {
            DelNummer = delNummer;
            Pris = pris;
            Tillverkare = tillverkare;
            Beskrivning = beskrivning;
            Bredd = bredd;
            Hojd = höjd;
            Diameter = diameter;
            Årstid = årsTid;
        }

        public string DisplayInfo()
        {
            return "Del nummer: " + DelNummer + ", Pris: " + Pris +
                ", Tillverkare: " + Tillverkare + ", Beskrivning: " + Beskrivning +
                ", Bredd: " + Bredd + ", Höjd: " + Hojd + ", Diameter: " + Diameter +
                ", Årstid: " + Årstid;
        }
    }

}
