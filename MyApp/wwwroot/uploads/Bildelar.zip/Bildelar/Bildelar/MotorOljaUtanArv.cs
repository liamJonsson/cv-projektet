﻿using System;
namespace Bildelar
{
    public class MotorOljaUtanArv
    {
        public string DelNummer { get; set; }
        public double Pris { get; set; }
        public string Tillverkare { get; set; }
        public string Beskrivning { get; set; }
        public string OljaTyp { get; set; }
        public string Viskositetsklass { get; set; }

        public MotorOljaUtanArv(string delNummer, double pris, string tillverkare,
            string beskrivning, string oljaTyp, string viskositetsKlass)
        {
            DelNummer = delNummer;
            Pris = pris;
            Tillverkare = tillverkare;
            Beskrivning = beskrivning;
            OljaTyp = oljaTyp;
            Viskositetsklass = viskositetsKlass;
        }
        public string DisplayInfo()
        {
            return "Del nummer: " + DelNummer + ", Pris: " + Pris + 
                ", Tillverkare: " + Tillverkare + ", Beskrivning: " + Beskrivning +
                ", OljaTyp: " + OljaTyp +", Viskositetsklass: " + Viskositetsklass;
        }
    }
}
