﻿using System;
using System.Collections.Generic;

namespace Bildelar
{
    class MainClass
    {
        public static void Main(string[] args)
        {

            Del del1 = new Dack("7126", 500, "Michelin", "Michelin Primacy Alpin PA3",
               205, 55, 16, "Vinterdäck");

            Console.WriteLine(del1.DisplayInfo());

            Del del2 = new Dack("40192773840991", 2131, "Continental", "Continental CONTISPORTCONTACT 3",
                275, 35, 18, "Sommardäck");

            Del del3 = new MotorOlja("134294", 615, "Mobil", "Mobil ESP1 1 Motorolja",
                 "Helsyntetisk olja", "5W-30");

            Console.WriteLine("Alla delar: ");
            List<Del> bilDelar = new List<Del>();
            bilDelar.Add(del1);
            bilDelar.Add(del2);
            bilDelar.Add(del3);
            int i = 1;
            foreach (Del delObject in bilDelar)
            {
                Console.WriteLine("--- Del " + i);
                Console.WriteLine(delObject.DisplayInfo());
                i++;
            }

        }
    }
}
