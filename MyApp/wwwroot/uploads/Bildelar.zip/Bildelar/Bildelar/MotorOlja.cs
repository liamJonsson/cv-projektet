﻿using System;
namespace Bildelar
{
    public class MotorOlja : Del
    {
        public string OljaTyp { get; set; }
        public string Viskositetsklass { get; set; }

        public MotorOlja(string delNummer, double pris, string tillverkare,
    string beskrivning, string oljaTyp, string viskositetsKlass)
            : base(delNummer, pris, tillverkare, beskrivning)
        {
            OljaTyp = oljaTyp;
            Viskositetsklass = viskositetsKlass;
        }

        public override string DisplayInfo()
        {
            return base.DisplayInfo() + ", OljaTyp: " + OljaTyp +
                ", Viskositetsklass: " + Viskositetsklass;
        }

    }
}

